%TF.GenerationSoftware,KiCad,Pcbnew,9.0.7*%
%TF.CreationDate,2026-10-30T19:49:46-03:00*%
%TF.ProjectId,amemiya_probe_tower_dual,616d656d-6979-4615-9f70-726f62655f74,v1.0*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.7) date 2026-10-30 19:49:46*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,1.400000*%
%ADD11R,1.700000X1.700000*%
%ADD12C,1.700000*%
%ADD13C,1.600000*%
%ADD14RoundRect,0.250000X-0.600000X-0.725000X0.600000X-0.725000X0.600000X0.725000X-0.600000X0.725000X0*%
%ADD15O,1.700000X1.950000*%
G04 APERTURE END LIST*
D10*
%TO.C,R1*%
X16000000Y-16000000D03*
X21080000Y-16000000D03*
%TD*%
D11*
%TO.C,J_ADXL*%
X6500000Y-10000000D03*
D12*
X6500000Y-12540000D03*
X6500000Y-15080000D03*
X6500000Y-17620000D03*
X6500000Y-20160000D03*
X6500000Y-22700000D03*
X6500000Y-25240000D03*
X6500000Y-27780000D03*
%TD*%
D11*
%TO.C,J_TEMP*%
X9460000Y-4000000D03*
D12*
X12000000Y-4000000D03*
X14540000Y-4000000D03*
%TD*%
D13*
%TO.C,C1*%
X16000000Y-10000000D03*
X18500000Y-10000000D03*
%TD*%
D14*
%TO.C,J_CABLE*%
X7000000Y-43800000D03*
D15*
X9500000Y-43800000D03*
X12000000Y-43800000D03*
X14500000Y-43800000D03*
X17000000Y-43800000D03*
%TD*%
M02*
